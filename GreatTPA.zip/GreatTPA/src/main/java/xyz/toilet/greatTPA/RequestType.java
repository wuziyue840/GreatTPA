package xyz.toilet.greatTPA;

public enum RequestType {
   TPA_TO,
   TPA_HERE;

   // $FF: synthetic method
   private static RequestType[] $values() {
      return new RequestType[]{TPA_TO, TPA_HERE};
   }
}
